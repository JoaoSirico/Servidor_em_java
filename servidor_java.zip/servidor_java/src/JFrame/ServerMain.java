package JFrame;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

/**
 *
 */
public class ServerMain {
    private ServerSocket serverSocket;
    private JFormServidor jFormServidor;

    public ServerMain() {}

    public void setServerMain(ServerSocket serverSocket) {
        this.serverSocket = serverSocket;
    }
    
    private void abrirServidor() {
        try {
            while (!serverSocket.isClosed()) {
                Socket socket = serverSocket.accept();
                ClientHandler clientHandler = new ClientHandler(socket);
                
//                printarResposta("Novo Cliente Conectado");
                
                //Criar a Thread para lidar com o nobo cliente
                Thread thread = new Thread(clientHandler);
                thread.start();
            }
        } catch (IOException e) {
            e.printStackTrace();
            fecharServidor();
        }
    }
    
    private void printarResposta(String mensagem) {
        jFormServidor.adicionarLog(mensagem);
    }

    public void fecharServidor() {
        try {
            if (serverSocket != null) {
                serverSocket.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public void criarServidor(int porta, JFormServidor jFormServidor) {
        try {
            this.jFormServidor = jFormServidor;
            ServerSocket serverSocket = new ServerSocket(porta);
            
            this.serverSocket = serverSocket;
            Thread serverThread = new Thread(new Runnable() {
                @Override
                public void run() {
                    abrirServidor();
                }
            });
            serverThread.setDaemon(true);
            serverThread.start();
        } catch (IOException e) {
            fecharServidor();
            e.printStackTrace();
        }
    }
}
