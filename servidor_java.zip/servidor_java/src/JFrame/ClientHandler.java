package JFrame;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.util.ArrayList;
import java.util.UUID;

public class ClientHandler implements Runnable {
    public static ArrayList<ClientHandler> ClientHandlers = new ArrayList<>();
    
    private Socket socket;
    private BufferedReader bufferedReader;
    private BufferedWriter bufferedWriter;
    
    private String clientUsername;
    private String clientId;
    
    
    public ClientHandler(Socket socket) {
        try {
            this.socket = socket;
            this.bufferedReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            this.bufferedWriter = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
            this.clientUsername = bufferedReader.readLine();
            this.clientId = gerarIdClient();
            
            ClientHandlers.add(this);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public void broadCastMessage(String mensagem) {
        for (ClientHandler clientHandler: ClientHandlers) {
            try {
                if(!clientHandler.clientId.equals(clientId)) {
                    clientHandler.bufferedWriter.write(mensagem);
                    clientHandler.bufferedWriter.newLine();
                    clientHandler.bufferedWriter.flush();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    
    public void mensagemDireta() {}
    
    @Override
    public void run() {
        String mensagemCliente;
        
        while(socket.isConnected()) {
            try {
                mensagemCliente = bufferedReader.readLine();
                broadCastMessage(mensagemCliente);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    
    public void removerCliente() {
        ClientHandlers.remove(this);
    }
    
    public void fecharConexaoCliente(Socket socket, BufferedReader bufferedReader, BufferedWriter bufferedWriter) {
        try {
            if(bufferedReader != null) {
                bufferedReader.close();
            }
            if(bufferedWriter != null) {
                bufferedWriter.close();
            }
            if(socket != null) {
                socket.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public String gerarIdClient() {
        return UUID.randomUUID().toString();
    }
}
