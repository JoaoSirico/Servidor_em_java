package Client;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;

/**
 *
 * @author J
 */
public class ClientMain {
    
    private Socket socket;
    private ClientHandler handler;
    private PrintWriter output;

    public ClientMain(String enderecoServidor, int portaServidor, String username, TelasCliente.TelaClienteMensagens telaCliente) {
        try {
            this.socket = new Socket(enderecoServidor, portaServidor);
            handler = new ClientHandler(socket, telaCliente);
            this.output = new PrintWriter(this.socket.getOutputStream(), true);
            // Printa no sistema o nome do usuário, para o servidor conseguir pegar
            this.output.println(username);
        } catch (IOException e) {
            System.out.println("Erro: " + e.getMessage());
        }
    }
    
    public void mandarMensagem(String menssagem) {
        this.output.println(menssagem);
    }
    
    //Implementar o código de fechar a conexão com o Socket
    public void fecharConexao() {}
    
    //Por motivações de testes
//    public static void main(String[] args) {
//        TelasCliente.TelaClienteMain tela = new TelasCliente.TelaClienteMain();
//        ClientMain clientMain = new ClientMain("localhost", 1234, tela);
//    }
}
