package Client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.util.StringTokenizer;

/**
 *
 * @author J
 */
public class ClientHandler extends Thread {

    private Socket socket;
    private TelasCliente.TelaClienteMensagens tela;
    private BufferedReader input;

    public ClientHandler(Socket socket, TelasCliente.TelaClienteMensagens tela) {
        this.socket = socket;
        this.tela = tela;
        try {
            this.input = new BufferedReader(new InputStreamReader(this.socket.getInputStream()));
        } catch (IOException e) {
        }
    }

    @Override
    public void run() {
        String message;
        while (true) {
            try {
                if (this.socket.isConnected() && this.input != null) {
                    message = this.input.readLine();
                } else {
                    break;
                }
                if (message == null || message.equals("")) {
                    break;
                }
//                tela.repaint();
                System.out.println("Messagem: " + message);
            } catch (Exception ex) {
                System.out.println(ex.getMessage());
                break;
            }
        }
    }

}
