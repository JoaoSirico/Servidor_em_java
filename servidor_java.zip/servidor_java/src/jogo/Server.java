package jogo;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * Funções que criam o servidor
*/

public class Server {
    private ServerSocket serverSocket;
    
    public Server(ServerSocket serverSocket) {
        this.serverSocket = serverSocket;
    }
    
    public void iniciarServer() {
        try{
            while(!serverSocket.isClosed()){
                Socket socket = serverSocket.accept();
                System.out.println("Novo Cliente se conectou");
                ClientHandler clientHandler = new ClientHandler(socket);
                
                System.out.println("Número atual de clientes no servidor: " + CountClients.getClientsNumber());
                minimoPlayers(CountClients.getClientsNumber());
                Thread thread = new Thread(clientHandler);
                thread.start();
            }
        }catch(IOException e){
               e.printStackTrace();
        }
    }
    
    public void fecharServerSocket() {
        try{
            if(serverSocket != null){
                serverSocket.close();
            }
        }catch(IOException e){
            e.printStackTrace();
        }
    }
    
    public void minimoPlayers (int numeroClients) {
        if(numeroClients >= 2) {
            //Fazer tela para iniciar o jogo
            //Acho que um notão já ta bom
        }
    }
    
    public static void main(String[] args) throws IOException {
        ServerSocket serverSocket = new ServerSocket(1234);
        Server server = new Server(serverSocket);
        server.iniciarServer();
    }
}
