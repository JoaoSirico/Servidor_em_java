package jogo;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.util.Scanner;

/**
 * Cria o Cliente, cria uma thread para cada cliente que se conecta, 
 * para que seja possível todos se comunicarem ao mesmo tempo
 * @author J
 */
public class Client {
    
    private Socket socket;
    private BufferedReader bufferedReader;
    private BufferedWriter bufferedWriter;
    private String username;

    public Client(Socket socket, String username) {
        try {
            this.socket = socket;
            this.bufferedWriter = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
            this.bufferedReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            this.username = username;
        } catch (IOException e) {
            fecharTudo(socket, bufferedReader, bufferedWriter);
        }
    }

    public void enviarMensagem() {
        try {
            bufferedWriter.write(username);
            bufferedWriter.newLine();
            bufferedWriter.flush();

            Scanner scanner = new Scanner(System.in);
            while (socket.isConnected()) {
                String messageToSend = scanner.nextLine();
                bufferedWriter.write(username + ": " + messageToSend);
                bufferedWriter.newLine();
                bufferedWriter.flush();
            }
        } catch (IOException e) {
            fecharTudo(socket, bufferedReader, bufferedWriter);
        }
    }

    public void escutarMensagens() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                String msgFromServer;

                while (socket.isConnected()) {
                    try {
                        msgFromServer = bufferedReader.readLine();
                        System.out.println(msgFromServer);
                    } catch (IOException e) {
                        fecharTudo(socket, bufferedReader, bufferedWriter);
                    }
                }
            }
        }).start();
    }

    public void fecharTudo(Socket socket, BufferedReader bufferedReader, BufferedWriter bufferedWriter) {
        try {
            if (bufferedReader != null) {
                bufferedReader.close();
            }
            if (bufferedWriter != null) {
                bufferedWriter.close();
            }
            if (socket != null) {
                socket.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Por favor insira seu nome de usuário");
        String username = scanner.nextLine();
        try {
            Socket socket = new Socket("localhost", 1234);
            Client client = new Client(socket, username);
            client.escutarMensagens();
            client.enviarMensagem();
        } catch (IOException e) {
        }
    }
    
//    public static void conexao(String serverAdress, int port) {;
//        try {
//            Socket socket = new Socket(serverAdress, port);
//            Scanner scanner = new Scanner(System.in);
//            String username = scanner.nextLine();
//            Client client = new Client(socket, username);
//            client.escutarMensagens();
//            client.enviarMensagem();
//        } catch (IOException e) {
//        }
//    }
}
