package jogo;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.util.ArrayList;

/**
 * Funções do cliente, como mandar mensagem para todos, conexão e desconexão do servidor, vez na fila de mandar mensagem
 * 
 * @todo => Melhorar método de colocar ou tirar da fila
 * @author Joao Pedro
 */
public class ClientHandler implements Runnable {

    public static ArrayList<ClientHandler> clientHandlers = new ArrayList<>();
    private Socket socket;
    private BufferedReader bufferedReader;
    private BufferedWriter bufferedWriter;
    public String clientUsername;
    private boolean turnSendMessage;

    public ClientHandler(Socket socket) {
        try {
            this.socket = socket;
            this.bufferedWriter = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
            this.bufferedReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            this.clientUsername = bufferedReader.readLine();

            clientHandlers.add(this);
            CountClients.incrementClients();
            TurnManager.addClient(this);
            
            broadcastMessage("SERVER: " + clientUsername + " Entrou");
        } catch (IOException e) {
            CountClients.decrementClients();
            closeEverything(socket, bufferedReader, bufferedWriter);
        }
    }

    @Override
    public void run() {
        //Escutar as Mensagens
        //Função Block
        String messageFromClient;

        while (socket.isConnected()) {
            try {
                messageFromClient = bufferedReader.readLine();
                // A principio vou bloquear todas as mensagens, mas depois é melhor eu deixar ele pelo menos mandar a primeira
                boolean turnToSendMessage = getTurnMessage(clientUsername);
                
                if(!turnToSendMessage){
                    System.out.println("Não é sua vez de mandar mensagem >:( ");
                    continue;
                }
                broadcastMessage(messageFromClient);
                
                TurnManager.proximoCliente();
            } catch (IOException e) {
                closeEverything(socket, bufferedReader, bufferedWriter);
                break;
            }
        }
    }

    public void broadcastMessage(String messageToSend) {
        for (ClientHandler clientHandler : clientHandlers) {
            try {
                if (!clientHandler.clientUsername.equals(clientUsername)) {
                    clientHandler.bufferedWriter.write(messageToSend);
                    //NewLine => Envia a mensagem 
                    clientHandler.bufferedWriter.newLine();
                    clientHandler.bufferedWriter.flush();
                }
            } catch (IOException e) {
                closeEverything(socket, bufferedReader, bufferedWriter);
            }
        }
    }
    
    //Manda mensagem direta para o cliente
    public void directMessage() {
        
    }

    //Envia mensagem que o usuário desconectou
    public void removeClientHandler() {
        clientHandlers.remove(this);
        CountClients.decrementClients();
        broadcastMessage("O Usuário: " + clientUsername + " saiu da sessão :( ");
    }

    public void closeEverything(Socket socket, BufferedReader bufferedReader, BufferedWriter bufferedWriter) {
        removeClientHandler();
        try {
            if (bufferedReader != null) {
                bufferedReader.close();
            }
            if (bufferedWriter != null) {
                bufferedWriter.close();
            }
            if (socket != null) {
                socket.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public static void setTurnOn (ClientHandler clientHandler) {
        clientHandler.turnSendMessage = true;
    }
    
    public static void setTurnOff(ClientHandler clientHandler){
        clientHandler.turnSendMessage = false;
    }
    
    public void disableAllTurns () {
        for (ClientHandler clientHandler : clientHandlers) {
            if(!clientHandler.clientUsername.equals(clientUsername)) {
                setTurnOff(clientHandler);
            }
        }
    }
    
    public boolean getTurnMessage(String clientName) {
        System.out.println(clientName);
        for (ClientHandler clientHandler: clientHandlers) {
            if(clientHandler.clientUsername.equals(clientName)) {
               return clientHandler.turnSendMessage; 
            }
        }
        return false;
    }
    
}
