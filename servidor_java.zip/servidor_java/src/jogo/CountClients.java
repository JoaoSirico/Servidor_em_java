package jogo;

/**
 * Serve para contar quantos clientes estão no servidor
 * Vai funcionar para verificar se tem pelo menos 2 jogadores para iniciar o jogo
 * 
 * // ========== { Talvez transformar o número de login em um id } ==========
 * 
 * @author J
 */
public class CountClients {
    public static int clientsCount = 0;
    
    public static void incrementClients () {
        clientsCount++;
    }
    
    public static void decrementClients() {
        clientsCount--;
    }
    
    public static int getClientsNumber() {
        return clientsCount;
    }
}
