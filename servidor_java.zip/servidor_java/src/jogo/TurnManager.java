package jogo;

/**
 * Adicionar os clients em uma lista para verificar qual cliente pode mandar mensagem,
 * por enquanto quando não é a vez do cliente o buffer somente não é lido, mas seria dahora
 * fazer um thread.suspend para gastar menos processamento
 * 
 * 
 * @author J
 */
import java.util.ArrayList;

public class TurnManager {

    private static ArrayList<ClientHandler> clientList = new ArrayList<>();
    private static int currentClient = 0;

    public static void addClient(ClientHandler clientHandler) {
        if (clientList.isEmpty()) {
            System.out.println("Turno Ativo: " + clientHandler.clientUsername);
            clientHandler.setTurnOn(clientHandler);
        } else {
            System.out.println("Turno Inativo: " + clientHandler.clientUsername);
            clientHandler.setTurnOff(clientHandler);
        }

        clientList.add(clientHandler);
    }

    public static void proximoCliente() {
        if (clientList.isEmpty() || clientList.size() == 1) {
            return;
        }

        ClientHandler clientOff = clientList.get(currentClient);
        ClientHandler.setTurnOff(clientOff);

        System.out.println("Cliente Desativando: " + clientOff.clientUsername);

        //Caso a lista tenha acabado ela se zera
        currentClient = (currentClient + 1) % clientList.size();

        ClientHandler clientOn = clientList.get(currentClient);
        ClientHandler.setTurnOn(clientOn);

        System.out.println("Cliente Ativando: " + clientOn.clientUsername);
    }
}
