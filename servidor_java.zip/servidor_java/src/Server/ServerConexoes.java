package Server;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.UUID;

/**
 *
 * Aqui a Gente cria s informações da conexão do cliente
 */
public class ServerConexoes {
    
    private Socket socket;
    // Define o id do cliente
    private String idCliente;
    // Define o input digitado pelo cliente
    private BufferedReader input;
    // Lê a saída de dados do servidor
    private PrintWriter output;
    //Váriavel que armazena o nome do cliente
    private String username;
    
    
    
    public ServerConexoes(Socket socket) {
        this.socket = socket;
        this.idCliente = UUID.randomUUID().toString();
        try {
            // Atribui o campo de leitura e escrita para o socket do cliente
            this.input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            this.output = new PrintWriter(this.socket.getOutputStream(), true);
        } catch (IOException e) {
            System.out.println("Erro: " + e.getMessage());
        }
    }
    
    public Socket getSocket () {
        return socket;
    }
    
    public void finalizarSessaoCliente() {
        try {
            if(this.socket != null) {
                this.socket.close();
            }
            if(this.output != null) {
                this.output.close();
            }
            if(this.input != null) {
                this.input.close();
            }
        } catch (IOException e) {
            System.out.println("Erro: " +e.getMessage());
        }
    }
    
    public BufferedReader getInput() {
        return input;        
    }
    
    public String getId() {
        return idCliente;
    }
    
    public void setUsername(String username) {
        this.username = username;
    }
    
    public String getUsername() {
        return username;
    }
}
