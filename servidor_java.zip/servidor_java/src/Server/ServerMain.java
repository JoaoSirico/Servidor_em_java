package Server;

import java.io.IOException;
import java.util.List;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

/**
 *
 * @author J
 */
public class ServerMain extends Thread {

    private ServerSocket serverSocket;
    private List<ServerConexoes> clientes;
    private Telas.TelaServerHub servidorTela;

    /*
     * A "Tela" é o JForm que será recebido pelo servidor para replicar aos clientes
     */
    public ServerMain(int porta, Telas.TelaServerHub servidorTela) {
        try {
            this.serverSocket = new ServerSocket(porta);
            System.out.println("Servidor Rodando na porta: " + porta);
            this.clientes = new ArrayList<>();
            this.servidorTela = servidorTela;
        } catch (IOException e) {
            System.out.println("Erro: " + e.getMessage());
        }
    }

    @Override
    public void run() {
        Socket socket;
        try {
            socket = this.serverSocket.accept();
            //Para cada conexão que for feita devemos adicionar o cliente conectado ao array
            ServerConexoes cliente = new ServerConexoes(socket);
            
            
            novoCliente(cliente); // -> Adiciona no array local o cliente criado
            
            System.out.println("Nova conexão: " + cliente.getId());
            
            //Pega o que o cliente imprime no output (Username) ao entrar no servidor
            String username = cliente.getInput().readLine();
            if(!username.isEmpty()) {
                // Chama a função de atualizar a tela do servidor
                servidorTela.adicionarClientes(username, cliente.getId());
            }else {
                System.out.println("Não foi possível pegar o nome do usuário");
            }
            
            //Lógica para cuidar do novo cliente
            (new ServerHandlerConexoes(cliente, this, servidorTela)).start(); 
        } catch (IOException e) {
            System.out.println("Erro: " + e.getMessage());
        }
    }

    public synchronized void novoCliente(ServerConexoes cliente) throws IOException {
        this.clientes.add(cliente);
    }

    //Criar classe remover cliente
    public synchronized void removerCliente(ServerConexoes cliente) {

    }
}
