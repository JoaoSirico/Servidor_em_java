package Server;

import java.io.IOException;

/**
 *
 * Essa classe fica responsável por lidar com a entrada de dados de cada cliente
 * Aqui é possível criar elementos de BroadCast e etc
 * 
 */
public class ServerHandlerConexoes extends Thread {

    private ServerConexoes cliente;
    private ServerMain main;
    private Telas.TelaServerHub servidorTela;

    public ServerHandlerConexoes(ServerConexoes cliente, ServerMain server, Telas.TelaServerHub servidorTela) {
        this.cliente = cliente;
        this.main = server;
        this.servidorTela = servidorTela;
    }

    @Override
    public void run() {
        String message;
        while (true) {
            try {
                if (this.cliente.getSocket().isConnected() && this.cliente.getInput() != null) {
                    message = this.cliente.getInput().readLine();
                } else {
                    break;
                }
                if (message.equals("") || message.isEmpty()) {
                    break;
                }
                
                int tecla = Integer.parseInt(message);
                
                System.out.println("Tecla: " + tecla);
            } catch (IOException e) {
            }
        }
    }

}
